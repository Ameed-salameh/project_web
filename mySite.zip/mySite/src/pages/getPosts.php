<?php
require 'db.php'; // الاتصال بقاعدة البيانات

// جلب جميع المنشورات مع الأقسام والتاغات المرتبطة
$query = "
    SELECT posts.post_id, posts.post_name, posts.image_url, posts.details, posts.publish_date,
           categories.category_name,
           GROUP_CONCAT(tags.tag_name SEPARATOR ', ') AS tags
    FROM posts
    JOIN categories ON posts.category_id = categories.category_id
    LEFT JOIN post_tags ON posts.post_id = post_tags.post_id
    LEFT JOIN tags ON post_tags.tag_id = tags.tag_id
    GROUP BY posts.post_id
    ORDER BY categories.category_name ASC, posts.publish_date DESC
";

$stmt = $conn->prepare($query);
$stmt->execute();
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// إرجاع البيانات كـ JSON
echo json_encode($posts);
?>
