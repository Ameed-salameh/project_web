<?php
require 'db.php';

try {
    // جلب السلايدات التي تحتوي على is_visible = 1
    $query = "SELECT slide_name, slide_url FROM slide WHERE is_visible = 1 ORDER BY slide_id";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $slides = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$slides) {
        echo '<p>لا توجد سلايدات لعرضها.</p>';
        exit;
    }

    // بناء HTML
    $html = '<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">';

    // المؤشرات
    $html .= '<div class="carousel-indicators">';
    foreach ($slides as $index => $slide) {
        $activeClass = $index === 0 ? 'active' : '';
        $html .= '<button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="' . $index . '" class="' . $activeClass . '" aria-current="' . ($index === 0 ? 'true' : 'false') . '" aria-label="Slide ' . ($index + 1) . '"></button>';
    }
    $html .= '</div>'; // إغلاق carousel-indicators

    // محتوى السلايد
    $html .= '<div class="carousel-inner">';
    foreach ($slides as $index => $slide) {
        $activeClass = $index === 0 ? 'active' : '';
        $html .= '<div class="carousel-item ' . $activeClass . '">';
        $html .= '<img src="' . htmlspecialchars($slide['slide_url']) . '" class="d-block w-100" alt="' . htmlspecialchars($slide['slide_name']) . '">';
        $html .= '<div class="carousel-caption d-none d-md-block">';
        $html .= '<h5>' . htmlspecialchars($slide['slide_name']) . '</h5>';
        $html .= '</div>'; // إغلاق carousel-caption
        $html .= '</div>'; // إغلاق carousel-item
    }
    $html .= '</div>'; // إغلاق carousel-inner

    // أزرار التنقل
    $html .= '<a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-bs-slide="prev">';
    $html .= '<span class="carousel-control-prev-icon" aria-hidden="true"></span>';
    $html .= '<span class="visually-hidden">السابق</span>';
    $html .= '</a>';
    $html .= '<a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-bs-slide="next">';
    $html .= '<span class="carousel-control-next-icon" aria-hidden="true"></span>';
    $html .= '<span class="visually-hidden">التالي</span>';
    $html .= '</a>';

    $html .= '</div>'; // إغلاق carouselExampleIndicators

    echo $html;

} catch (PDOException $e) {
    echo "خطأ في الاتصال بقاعدة البيانات: " . $e->getMessage();
    exit;
}
?>
