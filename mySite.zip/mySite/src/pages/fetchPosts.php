<?php
require 'db.php';

// استعلام لجلب الأقسام والتاغات المرتبطة
$queryCategories = "
    SELECT 
        categories.category_id, 
        categories.category_name, 
        GROUP_CONCAT(DISTINCT tags.tag_name SEPARATOR ', ') AS tags
    FROM categories
    LEFT JOIN posts ON categories.category_id = posts.category_id
    LEFT JOIN post_tags ON posts.post_id = post_tags.post_id
    LEFT JOIN tags ON post_tags.tag_id = tags.tag_id
    GROUP BY categories.category_id
    ORDER BY categories.category_id
";
$stmtCategories = $conn->prepare($queryCategories);
$stmtCategories->execute();
$categories = $stmtCategories->fetchAll(PDO::FETCH_ASSOC);

// استعلام لجلب المنشورات فقط
$queryPosts = "
    SELECT 
        posts.post_id, 
        posts.post_name, 
        posts.image_url, 
        posts.details, 
        posts.price, 
        posts.category_id
    FROM posts
    WHERE posts.is_approved = 1
    ORDER BY posts.category_id, posts.post_id
";
$stmtPosts = $conn->prepare($queryPosts);
$stmtPosts->execute();
$posts = $stmtPosts->fetchAll(PDO::FETCH_ASSOC);

// بناء HTML
$html = '';
foreach ($categories as $category) {
    $html .= '<div class="mb-5">';
    $html .= '<h2 class="section-title">' . htmlspecialchars($category['category_name']) . '</h2>';

    // عرض التاغات الخاصة بالقسم
    if (!empty($category['tags'])) {
        $tags = explode(', ', $category['tags']);
        $html .= '<div class="tags-container" data-aos="fade-up" data-aos-delay="100">';
        foreach ($tags as $tag) {
            $html .= '<span onclick="goToTag(\'' . htmlspecialchars($tag) . '\')">' . htmlspecialchars($tag) . '</span>';
        }
        $html .= '</div>';
    }

    $html .= '<div class="row g-4">';

    // عرض المنشورات الخاصة بهذا القسم
    foreach ($posts as $post) {
        if ($post['category_id'] == $category['category_id']) {
            $html .= '<div class="col-md-4">';
            $html .= '<div class="item-card">';
            if (!empty($post['image_url'])) {
                $html .= '<div class="image-wrapper">';
                $html .= '<img src="' . htmlspecialchars($post['image_url']) . '" alt="' . htmlspecialchars($post['post_name']) . '">';
                $html .= '</div>';
            }
            $html .= '<div class="item-info">';
            $html .= '<h6>' . htmlspecialchars($post['post_name']) . '</h6>';
            $html .= '<p>' . htmlspecialchars($post['details']) . '</p>';
            if (!empty($post['price'])) {
                $html .= '<p class="price">' . htmlspecialchars($post['price']) . ' شيكل</p>';
            }
            $html .= '</div>'; // إغلاق item-info
            $html .= '</div>'; // إغلاق item-card
            $html .= '</div>'; // إغلاق col-md-4
        }
    }

    $html .= '</div>'; // إغلاق row
    $html .= '</div>'; // إغلاق القسم
}

echo $html;
?>
